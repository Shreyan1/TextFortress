#########################

# Run the run_first.bat to unzip first
# Run the run_second.bat to check if any python version is installed, else launch the installer
# Then go to Program Files x86 and access TextFortress
# Copy the UI.exe under /dist to anywhere in your PC